// Get the <span> element that closes the modal
var leave = document.getElementsByClassName("shut")[0];
var accept=document.getElementsByClassName("forward")[0];
var modal= document.getElementById("myModal");

// Get the modal
window.onload = function() {
      modal.style.display="block"; 
    };
accept.onclick= function() {
    
    modal.style.display="none";
    
};
